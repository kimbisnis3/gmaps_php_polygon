<link rel="stylesheet" href="../css/bootstrap/styleadmin.css">
<link rel="stylesheet" href="css/bootstrap/css/bootstrap.min.css">
<script src="css/jquery-1.12.2.min.js"></script>
<script src="css/bootstrap/js/bootstrap.min.js"></script>
<script src="css/bootstrap/js/bootstrap.js"></script>

   <div class="row-fluid">
   <a href="#" id="logo" class="fr" ><img src="../admin/image/a.png"></a>
    <h2>PEMERINTAH <br>KOTA SURAKARTA</h2>
  </div>

<!--!navigasi-->
  <nav class="navbar navbar-custom navbar-top" role="navigation">
    <div class="container-fluid" >
      <ul class="nav navbar-nav navbar-left">
        <li>
          <a href=""><span class="glyphicon glyphicon-home"></span> Halaman Utama</a>
        </li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
      <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="false" aria-expanded="false">Jenis Pemetaan<span class="caret"></span> </a>
          <ul class="dropdown-menu">
            <li><a href="../index.php">Kepadatan Penduduk</a></li>
            <li><a href="../petakk/index.php">Jumlah KK</a></li>
            <li><a href="index.php">Warga Miskin</a></li>
          </ul>
        </li>
        <li>
          <a href="admin/"><span class="glyphicon glyphicon-user"></span> Tentang Kami</a>
        </li>
        <li>
          <a href="admin/"><span class="glyphicon glyphicon-user"></span> Hubungi Kami</a>
        </li>
        <li>
          <a href="../admin/"><span class="glyphicon glyphicon-new-window"></span> Login</a>
        </li>
      </ul>
    </div>
  </nav>
